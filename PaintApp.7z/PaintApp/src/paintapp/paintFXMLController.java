
package paintapp;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

/**
 * Jednostavna paint aplikacija za crtanje u kojoj se određuje velicina i boja kista,
 * te čišćenje plohe
 * 
 * @author Dino dcurjak1@veleri.hr
 * @version 8.2
 */
public class paintFXMLController implements Initializable {
/**
 * FXML korisničkog sučelja temeljen na XML-u za definiranje korisničkog sučelja JavaFX aplikacije
 */
@FXML
private ColorPicker colorpicker;

@FXML
private TextField bsize;

@FXML
private Canvas canvas;

boolean toolSelected = false;


GraphicsContext brushTool;
    
    /**
     *  Metoda koja izvađa unos na canvas, te dohvaća unos iz bsize TextField za velicinu 
     * kista i boju kista iz colorpicker-a
     * 
     * @param url javni konačni URL klase proširuje Object implementira Serializable
     * @param rb javna apstraktna klasa ResourceBundle proširuje Objekt
     */

@Override
public void initialize(URL url, ResourceBundle rb) {
     
    brushTool = canvas.getGraphicsContext2D();
    canvas.setOnMouseDragged( e -> {
        double size = Double.parseDouble(bsize.getText());
        double x = e.getX() - size / 2;
        double y = e.getY() - size / 2;
        
        if(toolSelected && !bsize.getText().isEmpty())
            brushTool.setFill(colorpicker.getValue());
            brushTool.fillRoundRect(x, y, size, size, size, size);
    });
    }    
    /**
     * metoda koja vraca canvas(plohu) u prvobitno stanje
     * 
     * @param e prihvaca unos miša 
     */
    @FXML
    public void newCanvas (ActionEvent e ){
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFill(Color.WHITE);
        gc.clearRect(0, 0, 1200, 1200); 
    }
    /**
     *  metoda kojom se primjenjuje izmjena parametara kista
     * 
     * @param e prihvača unos miša
     */
    @FXML
    public void toolselected(ActionEvent e){
        toolSelected = true;
    }
    
}
