
package paintapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Dino
 */
public class PaintApp extends Application {
    /**
     * 
     * 
     * @param stage JavaFX Stage klasa je najviši nivo JavaFX spremnika.
     * Primarnu etapu konstruira platforma. Aplikacija može konstruirati dodatne objekte Stage
     * 
     * @throws Exception Ključna riječ throw u Javi koristi se za eksplicitno bacanje iznimke iz metode ili bilo kojeg bloka koda
     */
   
    @Override
    public void start(Stage stage) throws Exception {
      
        Parent root = FXMLLoader.load(getClass().getResource("paintFXML.fxml"));
        
        stage.setTitle("Paint App");
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
   

/**
 * 
 * @param args sadrži isporučene argumente naredbenog retka kao niz objekata String
 */
   
    public static void main(String[] args) {
        launch(args);
    }
    
}
