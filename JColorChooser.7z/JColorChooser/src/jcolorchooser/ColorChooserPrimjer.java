/**
 *
 * @author Dino
 */

package jcolorchooser;


import java.awt.event.*;    
import java.awt.*;    
import javax.swing.*;     
public class ColorChooserPrimjer extends JFrame implements ActionListener {    

JButton b;    
Container c; 

ColorChooserPrimjer(){    
    c=getContentPane();    
    c.setLayout(new FlowLayout());         
    b=new JButton("Boja");    
    b.addActionListener(this);         
    c.add(b);    
}    
public void actionPerformed(ActionEvent e) {    
Color initialcolor = Color.RED;    
Color boja = JColorChooser.showDialog(this,"Izaberi boju",initialcolor);    
c.setBackground(boja);    
}    
    
public static void main(String[] args) {    
    ColorChooserPrimjer ch=new ColorChooserPrimjer();    
    ch.setSize(400,400);    
    ch.setVisible(true);    
    ch.setDefaultCloseOperation(EXIT_ON_CLOSE);    
    }    
}   